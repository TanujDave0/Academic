/*
 * Project 4: CS 211 Fall 2020
 * Name: Tanuj Dave, NetID: tdave6
 * 
 * linked_list. h(header file)
*/

#ifndef linked_list

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

#define linked_list

typedef struct NODE {
    char* name;
    int burgers;
    int salads;
    char status;
    struct NODE* next;
} node;

// declaring all the functions.
void clearToEoln();
void doAdd(node** head, bool debug);
void doCallAhead(node** head, bool debug);
void doWaiting(node* head, bool debug);
void doRetrieve(node** head, bool debug);
void doList(node* head);
void doDisplay(node* head);
void doEstimateTime(node* head, bool debug);
bool equal(char* a , char* b);
bool doesNameExist(node* head , char* name, bool debug);
void addToList(node** head , char* name , int burgers , int salads , char status, bool debug);
bool updateStatus(node* head , char* name, bool debug);
char* retrieveAndRemove(node** head , int burgers , int salads, bool debug);
int countOrdersAhead(node* head , char* name);
int displayWaitingTime(node* head , char* name, bool debug);
void displayOrdersAhead(node* head , char* name);
void displayListInformation(node* head);
int getNextNWSChar();
int getPosInt();
char* getName();
void clearToEoln();
void printCommands();
int main();

#endif
