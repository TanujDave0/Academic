/*
 * Project 4: CS 211 Fall 2020
 * Name: Tanuj Dave, NetID: tdave6
 * 
 * linked_list.c (third source file)
*/
#include "linked_list.h"

// function that checks if two strings are equal.
bool equal(char* a , char* b) {
    if (a == NULL || b == NULL) {
        return false;
    }
    if (strlen(a) != strlen(b)) {
        return false;
    }
    for (int i = 0; i < strlen(a); i++) {
        if (a[i] != b[i]) {
            return false;
        }
    }
    return true;
}

// checks if a node with name 'name' exists in the linked list.
bool doesNameExist(node* head , char* name, bool debug) {
    if (head == NULL) {
        return false;
    }
    while (head != NULL) {
        if (equal(head->name , name)) {
            return true;
        }
        head = head->next;
    }
    return false;
}

// adds a node to the linked list.
void addToList(node** head , char* name , int burgers , int salads , char status, bool debug) {
    bool check = true; // boolean to see if its empty list.
    if (*head == NULL) {
        *head = (node*)malloc(sizeof(node)); // initialising the list.
        (*head)->next = NULL;
        check = false;
    }

    node* temp = *head;

    while (temp->next != NULL) {
        if (debug) {
            printf( "Visiting node %s with values %d and %d\n", temp->name, temp->burgers, temp->salads);
        }
        temp = temp->next;
    }

    if (check) { // if list already initialised.
        if (debug) {
            printf( "Visiting node %s with values %d and %d\n", temp->name, temp->burgers, temp->salads);
        }
        temp->next = (node*)malloc(sizeof(node));
        temp = temp->next;
    }
    temp->name = name;
    temp->burgers = burgers;
    temp->salads = salads;
    temp->status = status;
    temp->next = NULL;
}

// update the status of the call in order with name 'name'.
bool updateStatus(node* head , char* name, bool debug) {
    // if (!doesNameExist(head , name, debug)) {
    //     printf("No match found for the given name.Try again!\n");
    //     return false;
    // }

    while (head != NULL) {
        if (debug) {
            printf( "Visiting node %s with values %d and %d\n", head->name, head->burgers, head->salads);
        }
        if (equal(head->name , name)) {
            if (head->status == 'c') {
                head->status = 'i';
                break;
            } else {         // if order is already in restaurant.
                return false;
            }
        }
        head = head->next;
    }
    return true;
}

// function to remove the node from the list with burgers and salads less than the given amount.
char* retrieveAndRemove(node** head , int burgers , int salads, bool debug) {
    node* temp = *head;
    node* prev = NULL;
    char* name = NULL;
    
    while (temp != NULL) {
        if (temp->burgers <= burgers && temp->salads <= salads && temp->status == 'i') {
            if (debug && prev != NULL) {
                printf( "Visiting node %s with values %d and %d\n", temp->name, temp->burgers, temp->salads);
            }
            if (prev != NULL) { // if its not the head.
                prev->next = temp->next;
            } else {            // if its the head.
                *head = temp->next;
            }
            name = (char*)malloc(sizeof(char) * strlen(temp->name)); // allocating memory for returning the name
            strcpy(name , temp->name);
            // for (int i = 0; i < strlen(temp->name); i++) {
            //     name[i] = temp->name[i];
            // }
            free(temp->name); // freeing the name first.
            free(temp); // freeing the node.
            break;
        }
        if (debug) {
            printf( "Visiting node %s with values %d and %d\n", temp->name, temp->burgers, temp->salads);
        }
        prev = temp;
        temp = temp->next;
    }

    if (name == NULL) {  // if no node was removed.
        printf("No matching orders found.\n");
    }
    return name;
}

// counts the number of orders ahead of the node with name 'name'.
int countOrdersAhead(node* head , char* name) {
    int ans = 0;
    while (head != NULL) {
        if (equal(head->name , name)) { // if its the order.
            break;
        }
        ans++;
        head = head->next;
    }
    return ans;
}

// returns the estimated waiting time for the order.
int displayWaitingTime(node* head , char* name, bool debug) {
    int ans = 0;
    while (head != NULL) {
        if (equal(head->name , name)) { // if its the order.
            break;
        }
        if (debug) {
            printf( "Visiting node %s with values %d and %d\n", head->name, head->burgers, head->salads);
        }
        ans += head->burgers * 5;  // adding the time.
        ans += head->salads * 2;
        head = head->next;
    }
    return ans;
}

// display all the orders ahead of the given order.
void displayOrdersAhead(node* head , char* name) {
    while (head != NULL) {
        if (equal(head->name , name)) {
            break;
        }
        printf(" %s: %d burgers and %d salads \n" , head->name , head->burgers , head->salads);
        head = head->next;
    }
}

// display all the nodes in the list.
void displayListInformation(node* head) {
    while (head != NULL) {
        if (head->status == 'i') { // if its in restaurant
            printf("%s: %d burgers and %d salads, currently in the restaurant.\n" , head->name , head->burgers , head->salads);
        } else if (head->status == 'c') { // if its not in the retaurant.
            printf("%s: %d burgers and %d salads, currently not in the restaurant.\n" , head->name , head->burgers , head->salads);
        }
        head = head->next;
    }
}