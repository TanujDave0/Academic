/*
    Name: Tanuj Dave
    UIN: 665028452
    email: tdave6@uic.edu
*/
import java.util.Iterator;
import java.util.ListIterator;

public class GLProject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to project 1");
	}
}
